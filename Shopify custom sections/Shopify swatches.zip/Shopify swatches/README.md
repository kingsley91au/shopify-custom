# Product Page:
1. Copy product-template to the theme product template schema section.
2. Copy style.css to theme style.css
3. Copy product.liuqid to the theme product.liquid file.
4. In order to display the swatches, client needs to fill in the metafield: Swatch Colour Name.


# Create metafield:
1.  Name: Swatch Colour Name
    Namespace and Key: custom.swatch_colour_name
    Content type: Singole line text

2.  Name: Swatch Colour HEX
    Namespace and Key: custom.swatch_colour_hex
    Content type: Color

3.  Name: Swatch Image
    Namespace and Key: custom.swatch_image
    Content type: File

4.  Name: Swatch Group
    Namespace and Key: custom.swatch_group
    Content type: Product (List)

