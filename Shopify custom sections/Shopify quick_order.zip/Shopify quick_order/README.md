# Note:
1. Add Jquery Script to the theme if the theme doesn't have one.
2. Add the PNG file to Assets file.