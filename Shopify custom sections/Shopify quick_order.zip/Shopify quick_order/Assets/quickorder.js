function filterFunction() {
  var input, filter, ul, li, a, i, txtValue;
  input = document.querySelector(".quick_order_input");
  filter = input.value.toUpperCase();
  ul = document.querySelector(".quick_orderUL");
  li = ul.getElementsByTagName("li");
  for (i = 0; i < li.length; i++) {
      a = li[i].getElementsByTagName("a")[0];
      txtValue = a.textContent || a.innerText;
      if (txtValue.toUpperCase().indexOf(filter) > -1) {
          li[i].style.display = "";
      } else {
          li[i].style.display = "none";
      }
  }
}
function changeText(){
const quick_order_option = document.querySelectorAll(".quick_order_selection");
  const quick_order_btn_text = document.querySelectorAll(".btn_text_quick_order");

  for (let j=0; j<quick_order_option.length; j++) {
    const selected = quick_order_option[j].selectedOptions;
    console.log(selected);
    for (let i=0; i<selected.length; i++) {
      if(selected[i].hasAttribute("data-pre-order")){
        quick_order_btn_text[j].innerHTML = "Pre Order";
      }
      if(selected[i].hasAttribute("data-add-cart")){
        quick_order_btn_text[j].innerHTML = "Add To Cart"; 
      }
      if(selected[i]==""){
        quick_order_btn_text[j].innerHTML = "Sold Out";
      }
    }
  }
}
changeText();
const quick_order_option = document.querySelectorAll(".quick_order_selection");
const quick_order_btn_text = document.querySelectorAll(".btn_text_quick_order");

for (let j=0; j<quick_order_option.length; j++) {
  quick_order_option[j].addEventListener('change',(event)=>{
    const selected = event.target.selectedOptions;
    for (let i=0; i<selected.length; i++) {
      if(selected[i].hasAttribute("data-pre-order")){
        quick_order_btn_text[j].innerHTML = "Pre Order";
      }
      else if(selected[i].hasAttribute("data-add-cart")){
        quick_order_btn_text[j].innerHTML = "Add To Cart"; 
      }
//         else if(selected[i].hasAttribute("data-sold-out")){
//           quick_order_btn_text[j].innerHTML = "Sold Out";
//         }
    }
  });
}

