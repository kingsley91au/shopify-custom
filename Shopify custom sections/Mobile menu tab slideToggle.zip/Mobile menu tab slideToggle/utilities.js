mobileParentActiveAccordion: function(container, tab, content){
    $container = $(container);
    $tab = $(container).find(tab);
    $content = $(container).find(content);
    $newtab = $tab.parent();
    
    $(tab + '.active').parent().next().slideToggle();

    // $('body').on('click', tab, function(e){
    //   e.preventDefault();
    //   $(this).toggleClass('active');
    //   $(this).parent().next().slideToggle();
    // });
    $newtab.on('click', function(e){
      e.preventDefault();
      $(this).next().slideToggle();
    });
  }