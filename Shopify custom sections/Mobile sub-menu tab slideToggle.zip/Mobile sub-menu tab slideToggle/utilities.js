mobileParentActiveAccordion: function(container, tab, content){
  $container = $(container);
  $tab = $(container).find(tab);
  $content = $(container).find(content);

  $(tab + '.active').parent().next().slideToggle();

  $('.mobile-mega-menu_block .image-element__wrap').parent().parent().hide();
  
  $('body').on('click', tab, function(e){
    e.preventDefault();
    var $menuItem = $(this);
    $(this).toggleClass('active');
    $(this).parent().next().slideToggle();
    $tab.parent().parent().parent().not($menuItem.parent().next()).slideUp();
  });
}