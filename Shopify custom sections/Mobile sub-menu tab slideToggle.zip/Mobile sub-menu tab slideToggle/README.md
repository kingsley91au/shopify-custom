# Replace section:
1. Open utilities.js on file.
2. Find the section "mobileParentActiveAccordion"
3. Replace it
