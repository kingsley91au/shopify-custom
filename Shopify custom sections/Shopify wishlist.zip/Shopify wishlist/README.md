# Product Page:
1. Place {%- render 'button-wishlist', product: product -%} to the product page.

# Header:
1. Add top-bar.liquid to the top bar position

