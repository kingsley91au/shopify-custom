# Shopify Plus:
1. For Shopify plus script only.
2. Create Shipping in Script Editor.
3. Copy and paste.
4. Need to create specific shipping for these products.


