#Check whether cart items has a product with tag "Alcohol"
has_alcohol_tag = Input.cart.line_items.any? { |line_item| line_item.variant.product.tags.include?('Alcohol') }
MINIMUM_ORDER_AMOUNT = 70 #dollars required in cart to get discount

if has_alcohol_tag
  if Input.cart.subtotal_price_was >= (Money.new(cents:100) * MINIMUM_ORDER_AMOUNT)
    Input.shipping_rates.each do |shipping_rate|
      shipping_rate.change_name("PARCEL POST ALCOHOL-FREE")
      shipping_rate.apply_discount(shipping_rate.price, message: "Alcohol Free Standard Shipping!")
    end
  else Input.cart.subtotal_price_was < (Money.new(cents:100) * MINIMUM_ORDER_AMOUNT)
    Input.shipping_rates.each do |shipping_rate|
      shipping_rate.change_name("PARCEL POST ALCOHOL")
      shipping_rate.change_price(shipping_rate.price * 0 + Money.new(cents:100) * 10, message: "Alcohol Standard Shipping!")
    end
  end
end



Output.shipping_rates = Input.shipping_rates