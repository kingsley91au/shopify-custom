window.selectCallback = function (variant, selector, $element) {
    let $product;
    if ($element) {
        $product = $element.find(`.product-${selector.product.id}`);
    } else {
        $product = $(`.product-${selector.product.id}`);
    }
    const $productForm = $('.product_form, .shopify-product-form', $product);
    const variantInventory = $productForm.data('variant-inventory');

    if (variant) {
        if (variantInventory) {
            variantInventory.forEach(v => {
                if (v.id === variant.id) {
                    const currentVariant = variant;
                    currentVariant.inventory_quantity = v.inventory_quantity;
                    currentVariant.inventory_management = v.inventory_management;
                    currentVariant.inventory_policy = v.inventory_policy;
                }
            });
        }
    }

    //To selectCallback fucntion
    const preText = $("#your-name");
    const notify_form = $(".Notify_form");
	const delivery_date_form = $(".line-item-property__date");
 	const pre_btn_text = $("span.btn_text").data('pre-order');
 	const add_btn_text = $("span.btn_text").data('add-order');
 	const sold_out_text = $("span.btn_text").data('sold-out');
	const btn_text = document.querySelector(".btn_text_dyn");
    //console.log(btn_text);

    if (variant && variant.available === true && variant.inventory_quantity <= 0){
        preText.val("is_pre_order");
      	preText.attr("name","properties[:]");
        notify_form.hide();
      	delivery_date_form.show();
      	btn_text.innerHTML = pre_btn_text;
    }
    else if (variant && variant.available === true && variant.inventory_quantity > 0){
      	preText.val("");
      	preText.attr("name","");
		notify_form.hide();
      	delivery_date_form.hide();
      	btn_text.innerHTML = add_btn_text;
    }
	else{
		preText.val("");
        preText.attr("name","");
      	notify_form.show();
      	delivery_date_form.hide();
      	btn_text.innerHTML = sold_out_text;
      	console.log(btn_text);
  	}
	window.addEventListener('load', (event) => {
      var dtToday = new Date();

      var month = dtToday.getMonth() + 1;
      var day = dtToday.getDate();
      var year = dtToday.getFullYear();
      if(month < 10){
          month = '0' + month.toString();
      }
      if(day < 10){
          day = '0' + day.toString();
      }

      var maxDate = year + '-' + month + '-' + day;
      $('#delivery-date').attr('min', maxDate);
  });
}


window.addEventListener('load', (event) => {
    const notify_btn = document.querySelector(".Notify_btn");
    const close_btn = document.querySelector(".close_btn");
    const enquire_form = document.querySelector(".product_enquire_form");
    const fade = document.querySelector(".fade");

    notify_btn.addEventListener('click', () => {
        enquire_form.style.display = 'block';
        fade.style.display = 'block';
    });
    close_btn.addEventListener('click', () => {
        enquire_form.style.display = 'none';
        fade.style.display = 'none';
    });
    fade.addEventListener('click', () => {
        enquire_form.style.display = 'none';
        fade.style.display = 'none';
    });
});