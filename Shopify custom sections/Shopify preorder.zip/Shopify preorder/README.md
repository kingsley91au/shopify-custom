# Notes:

1. This pre-order addon is for theme only
2. Place Preorder.js to selectCallback function if the theme have one, or add JS file under Assets. 
    - `<script src="{{ 'Preorder.js' | asset_url }}"></script>` before the closing `</head>` tag
3. Add settings_schema.json content to your file.
4. Place Product-from to your product-form
5. Place en.default.json to your file.

That's it! Contact me if there is any bugs: (kingsley@thehopefacotry.com)
