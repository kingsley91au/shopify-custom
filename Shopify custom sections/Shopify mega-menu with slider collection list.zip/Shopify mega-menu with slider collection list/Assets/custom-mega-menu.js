let isloaded = false;
let isTopPrevStop = false;
let isTopNextStop = false;
var arrowClickTop = 0;
var arrowStopItemTop = 0;

let isBottomPrevStop = false;
let isBottomNextStop = false;
var arrowClickBottom = 0;
var arrowStopItemBottom = 0;

function getTopCollectionContainter() {
    return document.querySelector("header.search-enabled--true .nav-desktop__tier-2 .top-collection .drop_down_collection_containter");
}
function getBottomCollectionContainter() {
    return document.querySelector("header.search-enabled--true .nav-desktop__tier-2 .bottom-collection .drop_down_collection_containter");
}
function getAllCollections() {
    return document.querySelectorAll("header.search-enabled--true .nav-desktop__tier-2 .dropdown_column_collections");
}
function getTopCollections() {
    return document.querySelector("header.search-enabled--true .nav-desktop__tier-2 .dropdown_column_collections .top-collection");
}
function getBottomCollections() {
    return document.querySelector("header.search-enabled--true .nav-desktop__tier-2 .dropdown_column_collections .bottom-collection");
}
function getTopImageSize() {
    return document.querySelectorAll("header.search-enabled--true .nav-desktop__tier-2 .top-collection .image__container_mega_menu img");
}
function getBottomImageSize() {
    return document.querySelectorAll("header.search-enabled--true .nav-desktop__tier-2 .bottom-collection .image__container_mega_menu img");
}
function getTopImageContainter() {
    return document.querySelectorAll("header.search-enabled--true .nav-desktop__tier-2 .top-collection .image__container_mega_menu");
}
function getBottomImageContainter() {
    return document.querySelectorAll("header.search-enabled--true .nav-desktop__tier-2 .bottom-collection .image__container_mega_menu");
}
function getTopDot() {
    return document.querySelectorAll("header.search-enabled--true .nav-desktop__tier-2 .top-collection .dots .dot");
}
function getBottomDot() {
    return document.querySelectorAll("header.search-enabled--true .nav-desktop__tier-2 .bottom-collection .dots .dot");
}
function getTopCollectionsSize() {
    return TopImageContainter.length;
}
function getBottomCollectionsSize() {
    return BottomImageContainter.length;
}
function getTopPrev() {
    return document.querySelector("header.search-enabled--true .nav-desktop__tier-2 .top-collection .arrow-dots .mega_prev");
}
function getTopNext() {
    return document.querySelector("header.search-enabled--true .nav-desktop__tier-2 .top-collection .arrow-dots .mega_next");
}
function getBottomPrev() {
    return document.querySelector("header.search-enabled--true .nav-desktop__tier-2 .bottom-collection .arrow-dots .mega_prev");
}
function getBottomNext() {
    return document.querySelector("header.search-enabled--true .nav-desktop__tier-2 .bottom-collection .arrow-dots .mega_next");
}

if(!isloaded) {
  setTimeout(() => {
    let elementWidth = window.innerWidth*0.7-30;
    let imageWidth = elementWidth/5;
    collections = getAllCollections();

    for(let i = 0; i<=collections.length-1; i++){
        if(collections.length<=1){
            collections[0].classList.add("top-collection");
        }
        else{
            collections[0].classList.add("top-collection");
            collections[1].classList.add("bottom-collection");
        }
    }

    topCollectionContainter = getTopCollectionContainter();
    bottomCollectionContainter = getBottomCollectionContainter();
    topCollectionContainter.style.width = elementWidth +'px';

    if(bottomCollectionContainter){
      bottomCollectionContainter.style.width = elementWidth +'px';
    }
    

    topImageSize = getTopImageSize();
    bottomImageSize = getBottomImageSize();
    
    TopImageContainter = getTopImageContainter();
    BottomImageContainter = getBottomImageContainter();
    
    collectionTop = getTopCollections();
    collectionBottom = getBottomCollections();

    TopDot = getTopDot();
    BottomDot = getBottomDot();

    TopCollectionsSize = getTopCollectionsSize();
    BottomCollectionSize = getBottomCollectionsSize();

    TopPrev = getTopPrev();
    TopNext = getTopNext();
    BottomPrev = getBottomPrev();
    BottomNext = getBottomNext();

    switch(TopCollectionsSize){
        case 6:
            arrowStopItemTop = 1;
            break;
        case 7:
            arrowStopItemTop = 2;
            break;
        case 8:
            arrowStopItemTop = 3;
            break;
        case 9:
            arrowStopItemTop = 4;
            break;
        case 10:
            arrowStopItemTop = 5;
            break;
    }

    switch(BottomCollectionSize){
        case 6:
            arrowStopItemBottom = 1;
            break;
        case 7:
            arrowStopItemBottom = 2;
            break;
        case 8:
            arrowStopItemBottom = 3;
            break;
        case 9:
            arrowStopItemBottom = 4;
            break;
        case 10:
            arrowStopItemBottom = 5;
            break;
    }
    
    for(let i = 0; i<=TopDot.length-1; i++){
        TopDot[0].classList.add("activate");
    }
    for(let i = 0; i<=BottomDot.length-1; i++){
        BottomDot[0].classList.add("activate");
    }

    if(TopCollectionsSize >=6 && TopCollectionsSize <=8){
      for(let i = 0; i<=TopDot.length-1; i++){
        TopDot[2].style.display="none";
      }
    }
    else if(TopCollectionsSize < 6){
      for(let i = 0; i<=TopDot.length-1; i++){
        TopDot[1].style.display="none";
        TopDot[2].style.display="none";
      }
    }

    if(BottomCollectionSize >=6 && BottomCollectionSize <=8){
        for(let i = 0; i<=BottomDot.length-1; i++){
            BottomDot[2].style.display="none";
        }
      }
      else if(BottomCollectionSize < 6){
        for(let i = 0; i<=TopDot.length-1; i++){
            BottomDot[1].style.display="none";
            BottomDot[2].style.display="none";
        }
      }

    for(let i = 0; i<=TopDot.length-1; i++){
        TopDot[0].addEventListener('click',(e)=>{
            for(let j=0; j<=topImageSize.length-1; j++){
                TopImageContainter[j].style.transform = 'translateX(-' + 0 + '00%)';
                TopImageContainter[j].style.transition = '0.5s';
                TopDot[1].classList.remove("activate");
                TopDot[2].classList.remove("activate");
                TopDot[0].classList.add("activate");
                arrowClickTop = 0;
            }
      });
      TopDot[1].addEventListener('click',(e)=>{
        for(let j=0; j<=topImageSize.length-1; j++){
            TopImageContainter[j].style.transform = 'translateX(-' + 2 + '00%)';
            TopImageContainter[j].style.transition = '0.5s';
            TopDot[0].classList.remove("activate");
            TopDot[2].classList.remove("activate");
            TopDot[1].classList.add("activate");
            arrowClickTop = 2;
        }
      });
      TopDot[2].addEventListener('click',(e)=>{
        for(let j=0; j<=topImageSize.length-1; j++){
            TopImageContainter[j].style.transform = 'translateX(-' + 4 + '00%)';
            TopImageContainter[j].style.transition = '0.5s';
            TopDot[0].classList.remove("activate");
            TopDot[1].classList.remove("activate");
            TopDot[2].classList.add("activate");
            arrowClickTop = 4;
        }
      })
    }
    for(let i = 0; i<=BottomDot.length-1; i++){
        BottomDot[0].addEventListener('click',(e)=>{
            for(let j=0; j<=bottomImageSize.length-1; j++){
                BottomImageContainter[j].style.transform = 'translateX(-' + 0 + '00%)';
                BottomImageContainter[j].style.transition = '0.5s';
                BottomDot[1].classList.remove("activate");
                BottomDot[2].classList.remove("activate");
                BottomDot[0].classList.add("activate");
                arrowClickBottom = 0;
            }
        });
        BottomDot[1].addEventListener('click',(e)=>{
            for(let j=0; j<=bottomImageSize.length-1; j++){
                BottomImageContainter[j].style.transform = 'translateX(-' + 2 + '00%)';
                BottomImageContainter[j].style.transition = '0.5s';
                BottomDot[0].classList.remove("activate");
                BottomDot[2].classList.remove("activate");
                BottomDot[1].classList.add("activate");
                arrowClickBottom = 2;
            }
        });
        BottomDot[2].addEventListener('click',(e)=>{
            for(let j=0; j<=bottomImageSize.length-1; j++){
                BottomImageContainter[j].style.transform = 'translateX(-' + 4 + '00%)';
                BottomImageContainter[j].style.transition = '0.5s';
                BottomDot[0].classList.remove("activate");
                BottomDot[1].classList.remove("activate");
                BottomDot[2].classList.add("activate");
                arrowClickBottom = 4;
            }
        })
    }

    for(let i = 0; i<=topImageSize.length-1; i++){
        topImageSize[i].style.width = imageWidth +'px';
    }
    for(let i = 0; i<=bottomImageSize.length-1; i++){
        bottomImageSize[i].style.width = imageWidth +'px';
    }

    TopPrev.addEventListener('click',()=>{
        if(arrowClickTop > 0){
            arrowClickTop -= 1;
            isTopPrevStop = false;
          }
          else{
            isTopPrevStop = true;
          }
          if(!isTopPrevStop){
            if(arrowClickTop >= 0 && arrowClickTop <= 1){
              for(let i = 0; i<=TopDot.length-1; i++){
                TopDot[0].classList.add("activate");
                TopDot[1].classList.remove("activate");
                TopDot[2].classList.remove("activate");
              }
            }
            else if(arrowClickTop >= 2 && arrowClickTop <= 3){
              for(let i = 0; i<=TopDot.length-1; i++){
                TopDot[1].classList.add("activate");
                TopDot[0].classList.remove("activate");
                TopDot[2].classList.remove("activate");
              }
            }
            else if(arrowClickTop >= 3 && arrowClickTop <= 4){
              for(let i = 0; i<=TopDot.length-1; i++){
                TopDot[2].classList.add("activate");
                TopDot[1].classList.remove("activate");
                TopDot[0].classList.remove("activate");
              }
            }
            for(let i=0; i<=topImageSize.length-1; i++){
                TopImageContainter[i].style.transform = 'translateX(' + -arrowClickTop + '00%)';
                TopImageContainter[i].style.transition = '0.5s';
            }
        }
        else{
            return false;
        }
    });
    TopNext.addEventListener('click',()=>{
        arrowClickTop += 1;
        if(arrowClickTop > arrowStopItemTop){
            isTopNextStop = true;
            arrowClickTop = arrowStopItemTop;
        }
        else{
            isTopNextStop = false;
        }
        if(!isTopNextStop){
            if(arrowClickTop >= 0 && arrowClickTop <= 1){
              for(let i = 0; i<=TopDot.length-1; i++){
                  TopDot[0].classList.add("activate");
                  TopDot[1].classList.remove("activate");
                  TopDot[2].classList.remove("activate");
              }
            }
            else if(arrowClickTop >= 2 && arrowClickTop <= 3){
              for(let i = 0; i<=TopDot.length-1; i++){
                  TopDot[1].classList.add("activate");
                  TopDot[0].classList.remove("activate");
                  TopDot[2].classList.remove("activate");
              }
            }
            else if(arrowClickTop >= 3 && arrowClickTop <= 4){
              for(let i = 0; i<=TopDot.length-1; i++){
                  TopDot[2].classList.add("activate");
                  TopDot[1].classList.remove("activate");
                  TopDot[0].classList.remove("activate");
              }
            }
            for(let i=0; i<=topImageSize.length-1; i++){
                TopImageContainter[i].style.transform = 'translateX(-' + arrowClickTop + '00%)';
                TopImageContainter[i].style.transition = '0.5s';
            }
        }
        else{
            return false;
        }
    })
    BottomPrev.addEventListener('click',()=>{
        if(arrowClickBottom > 0){
            arrowClickBottom -= 1;
            isBottomPrevStop = false;
          }
          else{
            isBottomPrevStop = true;
          }
          if(!isBottomPrevStop){
            if(arrowClickBottom >= 0 && arrowClickBottom <= 1){
              for(let i = 0; i<=BottomDot.length-1; i++){
                BottomDot[0].classList.add("activate");
                BottomDot[1].classList.remove("activate");
                BottomDot[2].classList.remove("activate");
              }
            }
            else if(arrowClickBottom >= 2 && arrowClickBottom <= 3){
              for(let i = 0; i<=BottomDot.length-1; i++){
                BottomDot[1].classList.add("activate");
                BottomDot[0].classList.remove("activate");
                BottomDot[2].classList.remove("activate");
              }
            }
            else if(arrowClickBottom >= 3 && arrowClickBottom <= 4){
              for(let i = 0; i<=BottomDot.length-1; i++){
                BottomDot[2].classList.add("activate");
                BottomDot[1].classList.remove("activate");
                BottomDot[0].classList.remove("activate");
              }
            }
            for(let i=0; i<=bottomImageSize.length-1; i++){
                BottomImageContainter[i].style.transform = 'translateX(' + -arrowClickBottom + '00%)';
                BottomImageContainter[i].style.transition = '0.5s';
            }
        }
        else{
            return false;
        }
    })
    BottomNext.addEventListener('click',()=>{
        arrowClickBottom += 1;
        if(arrowClickBottom > arrowStopItemBottom){
            isBottomNextStop = true;
            arrowClickBottom = arrowStopItemBottom;
        }
        else{
            isBottomNextStop = false;
        }
        if(!isBottomNextStop){
            if(arrowClickBottom >= 0 && arrowClickBottom <= 1){
            for(let i = 0; i<=BottomDot.length-1; i++){
                BottomDot[0].classList.add("activate");
                BottomDot[1].classList.remove("activate");
                BottomDot[2].classList.remove("activate");
            }
            }
            else if(arrowClickBottom >= 2 && arrowClickBottom <= 3){
            for(let i = 0; i<=BottomDot.length-1; i++){
                BottomDot[1].classList.add("activate");
                BottomDot[0].classList.remove("activate");
                BottomDot[2].classList.remove("activate");
            }
            }
            else if(arrowClickBottom >= 3 && arrowClickBottom <= 4){
            for(let i = 0; i<=BottomDot.length-1; i++){
                BottomDot[2].classList.add("activate");
                BottomDot[1].classList.remove("activate");
                BottomDot[0].classList.remove("activate");
            }
            }
            for(let i=0; i<=bottomImageSize.length-1; i++){
                BottomImageContainter[i].style.transform = 'translateX(-' + arrowClickBottom + '00%)';
                BottomImageContainter[i].style.transition = '0.5s';
            }
        }
        else{
            return false;
        }
    })

  }, 300)
}